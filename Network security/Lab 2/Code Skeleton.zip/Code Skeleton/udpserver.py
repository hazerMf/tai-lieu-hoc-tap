import socket

# Address and host
addr = '127.0.0.1'
port = 5000

# Create the server socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((addr, port))

# listen and connect to the client
# ------ Student code here ------


# Received the message from the client and print it to the terminal
# ------ Student code here ------


# Send the message "ACK" to the clinet
# ------ Student code here ------


# Close the connection
server_socket.close()
