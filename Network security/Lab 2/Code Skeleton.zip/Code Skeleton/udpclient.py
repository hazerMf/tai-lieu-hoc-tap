import socket

# Address and host
addr = '127.0.0.1'
port = 5000

# Create the client socket and connect
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((addr, port))

# Send the message "Hello" to the server
# ------ Student code here ------


# Received the message from the server and print it to the terminal
# ------ Student code here ------


# Close the connection
client_socket.close()
